file(REMOVE_RECURSE
  "CMakeFiles/lab3.dir/code/common.cpp.o"
  "CMakeFiles/lab3.dir/code/common.cpp.o.d"
  "CMakeFiles/lab3.dir/code/filters.cpp.o"
  "CMakeFiles/lab3.dir/code/filters.cpp.o.d"
  "CMakeFiles/lab3.dir/code/main.cpp.o"
  "CMakeFiles/lab3.dir/code/main.cpp.o.d"
  "CMakeFiles/lab3.dir/code/matrix.cpp.o"
  "CMakeFiles/lab3.dir/code/matrix.cpp.o.d"
  "bin/lab3/lab3"
  "bin/lab3/lab3.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/lab3.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
