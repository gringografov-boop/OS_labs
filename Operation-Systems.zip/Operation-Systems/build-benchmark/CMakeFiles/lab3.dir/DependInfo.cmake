
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/mnt/c/Users/Гриша/OneDrive/Desktop/OS_Labs/Operation-Systems/lab3/code/common.cpp" "CMakeFiles/lab3.dir/code/common.cpp.o" "gcc" "CMakeFiles/lab3.dir/code/common.cpp.o.d"
  "/mnt/c/Users/Гриша/OneDrive/Desktop/OS_Labs/Operation-Systems/lab3/code/filters.cpp" "CMakeFiles/lab3.dir/code/filters.cpp.o" "gcc" "CMakeFiles/lab3.dir/code/filters.cpp.o.d"
  "/mnt/c/Users/Гриша/OneDrive/Desktop/OS_Labs/Operation-Systems/lab3/code/main.cpp" "CMakeFiles/lab3.dir/code/main.cpp.o" "gcc" "CMakeFiles/lab3.dir/code/main.cpp.o.d"
  "/mnt/c/Users/Гриша/OneDrive/Desktop/OS_Labs/Operation-Systems/lab3/code/matrix.cpp" "CMakeFiles/lab3.dir/code/matrix.cpp.o" "gcc" "CMakeFiles/lab3.dir/code/matrix.cpp.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
