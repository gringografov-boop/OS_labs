file(REMOVE_RECURSE
  "CMakeFiles/multithread.dir/mt_posix.cpp.o"
  "CMakeFiles/multithread.dir/mt_posix.cpp.o.d"
  "CMakeFiles/multithread.dir/mt_sync_posix.cpp.o"
  "CMakeFiles/multithread.dir/mt_sync_posix.cpp.o.d"
  "CMakeFiles/multithread.dir/thread.cpp.o"
  "CMakeFiles/multithread.dir/thread.cpp.o.d"
  "libmultithread.a"
  "libmultithread.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/multithread.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
