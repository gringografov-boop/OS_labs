file(REMOVE_RECURSE
  "../bin/lab2/lab2_parent"
  "../bin/lab2/lab2_parent.pdb"
  "CMakeFiles/lab2_parent.dir/code/parent/main.cpp.o"
  "CMakeFiles/lab2_parent.dir/code/parent/main.cpp.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/lab2_parent.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
