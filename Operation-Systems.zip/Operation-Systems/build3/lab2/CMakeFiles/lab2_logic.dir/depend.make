# Empty dependencies file for lab2_logic.
# This may be replaced when dependencies are built.
