file(REMOVE_RECURSE
  "CMakeFiles/lab2_logic.dir/code/common.cpp.o"
  "CMakeFiles/lab2_logic.dir/code/common.cpp.o.d"
  "liblab2_logic.a"
  "liblab2_logic.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/lab2_logic.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
