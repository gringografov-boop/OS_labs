file(REMOVE_RECURSE
  "liblab2_logic.a"
)
