file(REMOVE_RECURSE
  "../bin/lab2/lab2_child"
  "../bin/lab2/lab2_child.pdb"
  "CMakeFiles/lab2_child.dir/code/child/main.cpp.o"
  "CMakeFiles/lab2_child.dir/code/child/main.cpp.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/lab2_child.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
